#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct fabricante
{
    char nome[50];
    char site[100];
    char uf[4];  /* Ex.: São Paulo = SP; Tocantins = TO */
};
struct produto   
{
    char nome[50];
    struct fabricante fabricante;
    char descricao[100];
    float peso;
    float valorDeCompra;
    float valorDeVenda;
    float lucro;
    float percentualDeLucro;
};



int main()
{
    system("cls");   /* Função que limpa o prompt de comando */

    struct produto produtos[10];   /* Reservando espaço para armazenar 10 prudutos */
    int opcao, opcao2;                     /* Variavel que direciona o fluxo do programa */
    int i;
    int sentinela;
    int retornoDeStrcmp;
    char ufDesejada[4];


    printf("\n-----------------------------------------\n");
    printf("            Bem-vindo ao sistema!            ");
    printf("\n-----------------------------------------\n\n");

    do
    {
        printf("1 - Adiciona um produto\n2 - Consulta aos produtos\n3 - Sair\n\n");
        printf("Digite um valor correspondete a uma opcao:\n");
        scanf("%d", &opcao);
        fflush(stdin);  /* Linpa o buffer do teclado */

        switch(opcao)
        {
            case 1:
                for(i = 0; sentinela != -1; i++)
                {
                    //O programa pode quebrar caso o numero maximo de produtos seja utrapassado? 
                    printf("\n\nInforme o nome do produto:\n");
                    fgets(produtos[i].nome, 50, stdin);
                    fflush(stdin);

                    printf("\nInforme o fabricante do produto:\n");
                    scanf("%[^\n]", &produtos[i].fabricante.nome);
                    fflush(stdin);

                    printf("\nInforme o site do fabricante, se houver:\n");
                    scanf("%[^\n]", &produtos[i].fabricante.site);
                    fflush(stdin);

                    printf("\nInforme a UF do fabricante: (Ex.: SP, TO, AC. RJ):\n");
                    scanf("%[^\n]", &produtos[i].fabricante.uf);
                    fflush(stdin);

                    printf("\nForneca uma breve descricao do produto:\n");
                    fgets(produtos[i].descricao, 100, stdin);
                    fflush(stdin);

                    printf("\nInforme o peso do produto em quilogramas(Kg):\n");
                    scanf("%f", &produtos[i].peso);
                    fflush(stdin);

                    printf("\nInforme o valor de compra do produto:\n");
                    scanf("%f", &produtos[i].valorDeCompra);
                    fflush(stdin);

                    printf("\nInforme o valor de venda do produto:\n");
                    scanf("%f", &produtos[i].valorDeVenda);
                    fflush(stdin);

                    produtos[i].lucro = produtos[i].valorDeVenda - produtos[i].valorDeCompra;
                    produtos[i].percentualDeLucro = (produtos[i].lucro / produtos[i].valorDeVenda) * 100;

                    system("cls");

                    printf("Valor de compra do produto: R$ %.2f", produtos[i].valorDeCompra);
                    printf("\nValor de venda do produto: R$ %.2f", produtos[i].valorDeVenda);
                    printf("\n\nLucro obtido: R$ %.2f", produtos[i].lucro);
                    printf("\nPercentual de lucro: %.2f%%", produtos[i].percentualDeLucro);

                    getchar(); /* Pausa o programa */

                    system("cls");

                    printf("\n\n(-1) - Para sair ou Qualquer outro valor para continuar\n\n");
                    scanf("%d", &sentinela);
                    fflush(stdin);

                    system("cls");
                }    
                break;
            case 2:
                printf("\n\n0 - Sair\n1 - Listar todas as marcas\n2 - Listar todos os produtos\n");
                printf("3 - Listar os produtos de um determiando estado\n");
                printf("4 - Listar os produtos de uma determinada marca\n");
                printf("5 - Estado onde esta o produto mais caro\n6 - Fabricante que possui o produto mais barato\n");
                printf("7 - Listar produtos em ordem crescente de valor\n8 - Listar produtos em ordem crescente de maior lucro\n");
                        
                printf("\nDigite um valor correspondete a uma opcao:\n");
                scanf("%d", &opcao2);
                fflush(stdin);

                switch(opcao2)
                {
                    case 1:
                        system("cls");
                        
                        printf("\n-------------------------------\n");
                        printf("             MARCAS"                );
                        printf("\n-------------------------------\n");
                        for(i = 0; i < 3; i++)
                        {
                            printf("\n");
                            printf("%s", produtos[i].fabricante.nome);
                        }
                        getchar();
                        printf("\n\n\n");

                        break;

                    case 2:
                        system("cls");

                        printf("\n-------------------------------\n");
                        printf("            PRODUTOS                ");
                        printf("\n-------------------------------\n");
                        for(i = 0; i < 3; i++)
                        {
                            printf("\n");
                            printf("%s", produtos[i].nome );
                        }

                        getchar();
                        printf("\n\n\n");

                    case 3:
                        system("cls");

                        printf("\n-------------------------------\n");
                        printf("            PRODUTOS/UF               ");
                        printf("\n-------------------------------\n");

                        printf("Informe a UF:\n");
                        scanf("%[^\n]", &ufDesejada);
                        fflush(stdin);


                        for(i = 0; i < 3; i++)
                        {
                            retornoDeStrcmp = strcmp(produtos[i].fabricante.uf, ufDesejada);
                            if(retornoDeStrcmp == 0)
                            {
                                printf("\n%s", produtos[i].nome);
                            }
                            else
                            {
                                printf("\nNao consta nenhum produto!\n");
                                getchar();
                                break;
                            }

                        }

                        getchar();
                        printf("\n\n\n");

                    default:

                        break;
                }
                break;
            default:

                break;
        }
    }while(opcao != 3);
  return 0;
}