#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct fabricante
{
    char nome[50];
    char site[100];
    char telefone[20];
    char uf[4];  /* Ex.: São Paulo = SP; Tocantins = TO */
};
struct produto   
{
    char nome[50];
    struct fabricante fabricante;
    char descricao[100];
    float peso;
    float valorDeCompra;
    float valorDeVenda;
    float lucro;
    float percentualDeLucro;
};

void AdicionaP(struct produto produtos[]){
int i;
int sentinela;
for(i = 0; sentinela != -1; i++)
    {
    //O programa pode quebrar caso o numero maximo de produtos seja utrapassado? 
        printf("|--------------------------------------------------|\n");
        printf("|               Registro de Produto!               |\n");
        printf("|--------------------------------------------------|\n");
        printf("\n");
        printf("| Informe o nome do produto: ");
        fflush(stdin);
        scanf("%[^\n]", &produtos[i].nome);

        printf("| Informe o fabricante do produto: ");
        fflush(stdin);
        scanf("%[^\n]", &produtos[i].fabricante.nome);
        printf("\n");

        printf("| Informe o telefone do fabricante:");
        fflush(stdin);
        scanf("%[^\n]", produtos[i].fabricante.telefone);
        printf("\n");

        printf("| Informe o site do fabricante, se houver: ");
        fflush(stdin);
        scanf("%[^\n]", &produtos[i].fabricante.site);
        printf("\n");

        printf("| Informe a UF do fabricante: (Ex.: SP, TO, AC. RJ): ");
        fflush(stdin);
        scanf("%[^\n]", &produtos[i].fabricante.uf);
        printf("\n");

        printf("| Forneca uma breve descricao do produto: ");
        fflush(stdin);
        fgets(produtos[i].descricao, 100, stdin);
        printf("\n");

        printf("| Informe o peso do produto em quilogramas(Kg): ");
        fflush(stdin);
        scanf("%f", &produtos[i].peso);
        printf("\n");

        printf("| Informe o valor de compra do produto: ");
        fflush(stdin);
        scanf("%f", &produtos[i].valorDeCompra);
        printf("\n");

        printf("| Informe o valor de venda do produto: ");
        fflush(stdin);
        scanf("%f", &produtos[i].valorDeVenda);
        printf("\n");
        fflush(stdin);
        

        produtos[i].lucro = produtos[i].valorDeVenda - produtos[i].valorDeCompra;
        produtos[i].percentualDeLucro = (produtos[i].lucro / produtos[i].valorDeVenda) * 100;

        system("cls");

        printf("|--------------------------------------------------|\n");
        printf("|                Produto adicionado!               |\n");
        printf("|--------------------------------------------------|\n");
        printf("|Valor de compra do produto: R$ %.2f\n", produtos[i].valorDeCompra);
        printf("|Valor de venda do produto: R$ %.2f\n", produtos[i].valorDeVenda);
        printf("|Lucro obtido: R$ %.2f\n", produtos[i].lucro);
        printf("|Percentual de lucro: %.2f%%\n", produtos[i].percentualDeLucro);
        printf("|--------------------------------------------------|\n");

        getchar(); /* Pausa o programa */

        system("cls");

        printf("| Digite [qualquer tecla] para Adiciona outro produto         \n");
        printf("| Digite [-1] para sair do registro de produtos        \n");
        printf("| Digite:  ");
        fflush(stdin);
        scanf("%d", &sentinela);
        system("cls");
        } 
    system("pause");
    system("cls");    
}

void ConsultaP(struct produto produtos[]){
int op2, i, numP;
int retornoDeStrcmp, retornoDeStrcmp2;
char ufDesejada[4];
char MKDesejada[50];
int tamanho = sizeof(produtos) / sizeof(produtos[0]);


 do{
    printf("|---------------------------------------------------------------|\n");
    printf("|                      Consulta de Produtos!                    |\n");
    printf("|---------------------------------------------------------------|\n");
    printf("| Digite [ 0 ] para sair      \n");
    printf("| Digite [ 1 ] para Listar todas as marcas      \n");
    printf("| Digite [ 2 ] para Listar todos os produtos    \n");
    printf("| Digite [ 3 ] Listar os produtos de um determiando estado    \n");
    printf("| Digite [ 4 ] Listar os produtos de uma determinada marca    \n");
    printf("| Digite [ 5 ] Estado onde esta o produto mais caro  \n");
    printf("| Digite [ 6 ] Fabricante que possui o produto mais barato    \n");
    printf("| Digite [ 7 ] Listar produtos em ordem crescente de valor   \n");
    printf("| Digite [ 8 ] Listar produtos em ordem crescente de maior lucro \n");
    printf("| Digite:  ");
    scanf("%d",&op2);

    switch (op2)
        {
    case 1:

        system("cls");
                        
        printf("|-------------------------------|\n");
        printf("|             MARCAS            |\n");
        printf("|-------------------------------|\n");
        for(i = 0; i < 3; i++)
        {
            printf("\n");
            printf("| %s", produtos[i].fabricante.nome);
        }
        getchar();
        system("cls");

        break;
    case 2:
        system("cls");
                        
        printf("|-------------------------------|\n");
        printf("|            PRODUTOS           |\n");
        printf("|-------------------------------|\n");
        for(i = 0; i < 3; i++)
        {
            printf("\n");
            printf("| %s", produtos[i].nome);
        }
        getchar();
        system("cls");

        break;
    case 3:
        system("cls");

        printf("|-------------------------------|\n");
        printf("|           PRODUTOS/UF         |\n");
        printf("|-------------------------------|\n");
        printf("Informe a UF:\n");
        fflush(stdin);
        scanf("%[^\n]", &ufDesejada);
        fflush(stdin);


        for(i = 0; i < 3; i++)
            {
            retornoDeStrcmp = strcmp(produtos[i].fabricante.uf, ufDesejada);
            if(retornoDeStrcmp == 0)
                {
                    printf("| %s", produtos[i].nome);
                }
                else
                {
                    printf("| Nao consta nenhum produto!\n");
                    getchar();
                    break;
                }

                }

        getchar();
        system("cls");

        break;
    case 4:
        system("cls");

        printf("|-------------------------------------|\n");
        printf("|            MARCAS/PRODUTOS          |\n");
        printf("|-------------------------------------|\n");
        printf("Informe o nome da marca:\n");
        fflush(stdin);
        scanf("%[^\n]", &MKDesejada);
        fflush(stdin);


        for(i = 0; i < 3; i++)
            {
            retornoDeStrcmp2 = strcmp(produtos[i].fabricante.nome, MKDesejada);
            if(retornoDeStrcmp2 == 0)
                {
                    printf("| %s", produtos[i].nome);
                }
                else
                {
                    printf("| Nao consta nenhum produto!\n");
                    getchar();
                    break;
                }

                }

        getchar();
        system("cls");

        break;
    case 5:
        EPMC(produtos);
        system("cls");
        break;
    case 6:
        FPMB(produtos);
        system("cls");
        break;
    case 7:
        OPV(produtos);
        printf("Produtos em ordem crescente de valor:\n");
    for (int i = 0; i < numP; i++) {
        printf("Produto %d:\n", i + 1);
        printf("Descrição: %s\n", produtos[i].descricao);
        printf("Peso: %.2f\n", produtos[i].peso);
        printf("Valor de compra: %.2f\n", produtos[i].valorDeCompra);
        printf("Valor de venda: %.2f\n", produtos[i].valorDeVenda);
        printf("Valor do lucro: %.2f\n", produtos[i].lucro);
        printf("Percentual do lucro: %.2f\n", produtos[i].percentualDeLucro);
        printf("\n");
    }
        system("cls");
        break;
    case 8:
    // eu não consegui achar outra forma de fazer, presi
        OPL(produtos);
        printf("| Produtos em ordem crescente do maior valor do lucro:\n");
    for (int i = 0; i < tamanho; i++) {
        printf("| %s - Lucro: R$%.2f (%.2f%%)\n", produtos[i].descricao, produtos[i].lucro, produtos[i].percentualDeLucro);
    }
        system("cls");
        break;
    
    default:

        break;
        }
    }while (op2!=0);
	system("PAUSE");


}

void FPMB(struct produto produtos[]) {
    float menorvalor = produtos[0].valorDeVenda;
    char fabricantes[10][100];
    int numF = 0;
    int numP;

    for(int i = 1; i < numP; i++) {
        if (produtos[i].valorDeVenda > menorvalor) {
            menorvalor = produtos[i].valorDeVenda;
        }
    }
    for (int i = 0; i < numP; i++) {
        if (produtos[i].valorDeVenda == menorvalor) {
            int fabricanteEncontrado = 0;
            for (int j = 0; j < numF; j++) {
                if (strcmp(fabricantes[j], produtos[i].fabricante.nome) == 0) {
                    fabricanteEncontrado = 1;
                    break;
                }
            }
            if (!fabricanteEncontrado) {
                strcpy(fabricantes[numF], produtos[i].fabricante.nome);
                numF++;
            }
        }
    }
    printf("|---------------------------------------------------|\n");
    printf("|                       FPMB                        |\n");
    printf("|---------------------------------------------------|\n");
    printf("| Fabricante onde está o produto mais barato:\n");
    for (int i = 0; i < numF; i++) {
        printf("| %s\n", fabricantes[i]);
    }
    system("pause");
    system("cls");
}

void EPMC(struct produto produtos[]) {
    float maiorValor = produtos[0].valorDeVenda;
    char estados[10][3];
    int estadoEncontrado = 0;
    int numE = 0;
    int numP;
    
    // Encontrar o maior valor de venda
    for(int i = 1; i < numP; i++) {
        if (produtos[i].valorDeVenda > maiorValor) {
            maiorValor = produtos[i].valorDeVenda;
        }
    }
    // Verificar em quais estados o produto mais caro está registrado
    for (int i = 0; i < numP; i++) {
        if (produtos[i].valorDeVenda == maiorValor) {
            // Verificar se o estado já está na lista
            for (int j = 0; j < numE; j++) {
                if (strcmp(estados[j], produtos[i].fabricante.uf) == 0) {
                    estadoEncontrado = 1;
                    break;
                }
            }
            // Adicionar o estado à lista se não estiver presente
            if (!estadoEncontrado) {
                strcpy(estados[numE], produtos[i].fabricante.uf);
                numE++;
            }
        }
    }
    // Exibir os estados onde está registrado o produto mais caro
    printf("|---------------------------------------------------|\n");
    printf("|                       EPMC                        |\n");
    printf("|---------------------------------------------------|\n");
    printf("| UF aonde esta registrado o produto mais caro:\n");
    for (int i = 0; i < numE; i++) {
        printf("| %s\n", estados[i]);
    }
    system("pause");
    system("cls");
}

void OPV(struct produto produtos[]){
typedef Produto temp;
int i, j, minimo;
int numP;


    for (i = 0; i < numP - 1; i++) {
        minimo = i;
        
        // Encontra o índice do produto de menor valor a partir da posição atual
        for (j = i + 1; j < numP; j++) {
            if (produtos[j].valorDeVenda < produtos[minimo].valorDeVenda) {
                minimo = j;
            }
        }
        
        // Troca os produtos de posição
        if (minimo != i) {
            temp = produtos[i];
            produtos[i] = produtos[minimo];
            produtos[minimo] = temp;
        }
    }
}

void OPL(struct produto produtos[]){
int tamanho;
int i, j, IMX;
    struct Produto temp;

    for (i = 0; i < tamanho - 1; i++) {
     IMX = i;
        for (j = i + 1; j < tamanho; j++) {
            if (produtos[j].lucro < produtos [IMX].lucro) {
             IMX = j;
            }
        }
        temp = produtos [IMX];
        produtos [IMX] = produtos[i];
        produtos[i] = temp;
    }
}

int main(){
    struct produto produtos[10];
    system("cls"); /* Função que limpa o prompt de comando */
    int op;


    do{
    printf("|----------------------------------------------|\n");
    printf("|            Bem-vindo ao HotDrinks!           |\n");
    printf("|----------------------------------------------|\n");
    printf("| Digite [ 1 ] para Adiciona um produto         \n");
    printf("| Digite [ 2 ] para Consulta aos produtos       \n");
    printf("| Digite [ 3 ] para sair do site                \n");
    printf("| Digite:  ");
    scanf("%d",&op);

    switch (op)
        {
    case 1:
        AdicionaP(produtos);
        system("cls");
        break;
    case 2:
        ConsultaP(produtos);
        system("cls");
        break;
    default:

        break;
        }
    }while (op!=3);
	system("PAUSE");
    return 0;
}